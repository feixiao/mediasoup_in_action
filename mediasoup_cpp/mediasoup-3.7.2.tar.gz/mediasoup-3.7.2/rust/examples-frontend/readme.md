# Examples
This directory contains complementary frontend examples of using mediasoup Rust library.

NOTE: These examples are simplified and provided for demo purposes only, they are by no means complete or representative
of production-grade software, use for educational purposes only and refer to documentation for all possible options.

In order to run client-side part of examples (this directory) go to the directory with example and run following:
```bash
npm install
npm start
```

declare const randomNumberGenerator: (min?: number | null | undefined, max?: number | null | undefined, integer?: boolean | null | undefined) => number;
/**
 * Clones the given object/array.
 */
export declare function clone(data: any): any;
/**
 * Generates a random positive integer.
 */
export { randomNumberGenerator as generateRandomNumber };
//# sourceMappingURL=utils.d.ts.map
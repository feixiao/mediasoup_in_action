---
name: 🙈 Support Question
about: If you have any questions use the mediasoup Discourse Group
---

**IMPORTANT:** We primarily use GitHub as an issue tracker. Please, use the mediasoup Discourse Group if you have questions or doubts or if you need support about mediasoup and its ecosystem:

https://mediasoup.discourse.group

Before asking any questions, please check the mediasoup official documentation:

https://mediasoup.org/documentation/
